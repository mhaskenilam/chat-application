<?php


require 'Joomla.php';

class CBE_2 extends Joomla{}
