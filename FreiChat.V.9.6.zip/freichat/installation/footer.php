<div class="push"></div>
    </div>



    <div class="footer">
  <p style="text-align:center;font-size:8pt;">
    &#169;<?php echo date('Y'); ?> <a style="color: blue" href="http://codologic.com">Codologic.com</a> 
    - <a  style="color: blue" href="license.txt" target="_blank">Terms & Conditions</a>
</p>
    </div>
        <!-- external javascript
        ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->

        <!-- transition / effect library -->
        <script src="../administrator/js/bootstrap-transition.js"></script>
        <!-- alert enhancer library 
        <script src="../administrator/js/bootstrap-alert.js"></script>-->
        <!-- modal / dialog library -->
        <script src="../administrator/js/bootstrap-modal.js"></script>
        <!-- custom dropdown library 
        <script src="../administrator/js/bootstrap-dropdown.js"></script>-->
        <!-- scrolspy library 
        <script src="../administrator/js/bootstrap-scrollspy.js"></script>-->
        <!-- library for creating tabs 
        <script src="../administrator/js/bootstrap-tab.js"></script>-->
        <!-- library for advanced tooltip -->
        <script src="../administrator/js/bootstrap-tooltip.js"></script>
        <!-- popover effect library 
        <script src="../administrator/js/bootstrap-popover.js"></script>-->
        <!-- button enhancer library -->
        <script src="../administrator/js/bootstrap-button.js"></script>
        <!-- accordion library (optional, not used in demo) 
        <script src="../administrator/js/bootstrap-collapse.js"></script>-->
        <!-- carousel slideshow library (optional, not used in demo) 
        <script src="../administrator/js/bootstrap-carousel.js"></script>-->
        <!-- autocomplete library 
        <script src="../administrator/js/bootstrap-typeahead.js"></script>-->
        <!-- tour library 
        <script src="../administrator/js/bootstrap-tour.js"></script>-->
        <!-- library for cookie management -->
        <script src="../administrator/js/jquery.cookie.js"></script>
        <!-- calander plugin 
        <script src='../administrator/js/fullcalendar.min.js'></script>-->
        <!-- data table plugin -->
        <script src='../administrator/js/jquery.dataTables.min.js'></script>

        <!-- chart libraries start -->
        <!--<script src="../administrator/js/excanvas.js"></script>
        <script src="../administrator/js/jquery.flot.min.js"></script>
        <script src="../administrator/js/jquery.flot.pie.min.js"></script>
        <script src="../administrator/js/jquery.flot.stack.js"></script>
        <script src="../administrator/js/jquery.flot.resize.min.js"></script>-->
        <!-- chart libraries end -->

        <!-- select or dropdown enhancer -->
        <script src="../administrator/js/jquery.chosen.min.js"></script>
        <!-- checkbox, radio, and file input styler -->
        <script src="../administrator/js/jquery.uniform.min.js"></script>
        <!-- plugin for gallery image view 
        <script src="../administrator/js/jquery.colorbox.min.js"></script>-->
        <!-- rich text editor library 
        <script src="../administrator/js/jquery.cleditor.min.js"></script>-->
        <!-- notification plugin -->
        <script src="../administrator/js/jquery.noty.js"></script>
        <!-- file manager library 
        <script src="../administrator/js/jquery.elfinder.min.js"></script>-->
        <!-- star rating plugin 
        <script src="../administrator/js/jquery.raty.min.js"></script>-->
        <!-- for iOS style toggle switch -->
        <!--<script src="../administrator/js/jquery.iphone.toggle.js"></script>-->
        <!-- autogrowing textarea plugin 
        <script src="../administrator/js/jquery.autogrow-textarea.js"></script>-->
        <!-- multiple file upload plugin 
        <script src="../administrator/js/jquery.uploadify-3.1.min.js"></script>-->
        <!-- history.js for cross-browser state change on ajax -->
        <script src="../administrator/js/jquery.history.js"></script>
        <!-- application script for Charisma demo -->
        <script src="../administrator/js/charisma.js"></script>

        <script src="js/rainbow-custom.min.js"></script>
</body>
</html>
