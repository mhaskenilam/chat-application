<?php
/*
FreiChat - English language
cb->chatbox
g->guest
Do not use space but nbsp;
If you have copied this file and you are making your own
language then please write in the format similar to english.php
*/


$frei_trans['cb_head']="User";
$frei_trans['g_prefix']="Vendég-";
$frei_trans['pwdby']="Powered By";
$frei_trans['noline']="Nincs user";
$frei_trans['noperms']="Please&nbsp;LogIn&nbsp;to chat!";
$frei_trans['on_offline']="Fetching...User..List<br/>Querying DataBase<br/>..............................";
$frei_trans['go_online']="Online";
$frei_trans['go_offline']="Offline";
$frei_trans['go_invisible']="Rejtett";
$frei_trans['go_anonymous']="Névtelenül";
$frei_trans['go_busy']="Elfoglalt";
$frei_trans['newmesg']="Új üzenet";
$frei_trans['restore_drag_pos']="Restore Positions";
$frei_trans['status_txt']="Státusz";
$frei_trans['opt_txt']="Additional Options";

return 1;

/*Language file contributed by
Name    : encipoly
Email   : kis.erno@digitalvac.hu
*/
?>
